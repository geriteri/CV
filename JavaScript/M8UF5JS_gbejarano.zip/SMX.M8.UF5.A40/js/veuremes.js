function veureMes () {

    var x = document.getElementById("mestext");
    x.className = "visible";

    /*var y = document.getElementById("ocult");
    y.style.display = "none";*/
}