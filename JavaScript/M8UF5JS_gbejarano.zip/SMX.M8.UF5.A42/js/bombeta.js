function canvia(cosa) {
    cosa.src = "img/llumon.gif";
    console.log ("azul")
}
function apaga(cosa) {
    cosa.src = "img/llumoff.gif";
}
function trenca(cosa) {
    cosa.src = "img/llumbreak.gif";
}