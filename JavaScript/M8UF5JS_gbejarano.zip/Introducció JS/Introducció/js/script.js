function canvia() {
    var element = document.scripts("gris");

    element.innerHTML = "<p>Ara hem posat text al DIV</p>";
}